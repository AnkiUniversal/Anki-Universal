﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using AnkiU.AnkiCore;
using AnkiU.UIUtilities;
using AnkiU.Models;
using Windows.UI.Text;
using AnkiU.Anki;
using System.Threading.Tasks;
using AnkiU.ViewModels;
using AnkiRuntimeComponent;
using Windows.UI.Popups;
using AnkiU.Interfaces;
using Windows.UI.Core;
using Windows.ApplicationModel.DataTransfer;
using Windows.Storage;
using Windows.Data.Json;

namespace AnkiU.Views
{
    public sealed partial class NoteFieldView : UserControl, INightReadMode
    {
        public readonly string HTML_PATH;
        private bool isWebviewReady = false;
        private bool isNoteFieldPopulate = false;

        public bool IsModified { get; set; } = false;
        public bool IsContentCheckOnce { get; set; } = false;
        
        private WebView webViewControl;

        private Note currentNote;
        public Note CurrentNote
        {
            get { return currentNote; }
            set
            {
                currentNote = value;
                if (isWebviewReady)
                {
                    if (!isNoteFieldPopulate)
                    {
                        Task task = PopulateNoteField();
                    }
                    else
                    {
                        Task task = ChangeAllNoteFieldContent(currentNote);
                    }

                }
            }
        }

        private string deckMediaFolderName;
        public string DeckMediaFolderName
        {
            get { return deckMediaFolderName; }
            set
            {
                deckMediaFolderName = value;
                if(isWebviewReady)
                {
                    Task task = ChangeDeckMediaFolder(deckMediaFolderName);
                }
            }
        }

        private bool isNightMode = false;

        private ButtonPassingWebToWinRT buttonEventNotify;
        private EditableFieldPassWebToWinRT noteFieldEventNotify;        

        public event ClickEventHandler WebviewButtonClickEvent;
        public event EditableFieldRoutedEventHandler NoteFieldPasteEvent;

        private MenuFlyout menuFlyout;

        public NoteFieldView()
        {
            this.InitializeComponent();

            if (UIHelper.IsHasPhysicalKeyboard())
                HTML_PATH = "/html/fieldeditor.html";
            else
                HTML_PATH = "/html/fieldeditortouch.html";

            AddWebViewControlIntoGrid();

            menuFlyout = Resources["FieldContextMenu"] as MenuFlyout;

            buttonEventNotify = new ButtonPassingWebToWinRT();
            buttonEventNotify.ButtonClickEvent += ButtonEventNotifyClickEventHandler;

            noteFieldEventNotify = new EditableFieldPassWebToWinRT();
            noteFieldEventNotify.EditableFieldTextChangedEvent += NoteFieldTextChangedEventHandler;
            noteFieldEventNotify.EditableFieldPasteEvent += NoteFieldPasteEventHandler;
            noteFieldEventNotify.EditableContextMenuEvent += NoteFieldContextMenuEventHandler;            
        }

        private async void NoteFieldContextMenuEventHandler(object obj)
        {
            var array = obj as object[];
            var offsetX = (double)array[0];
            var offsetY = (double)array[1];            
            contextMenuPlace.Margin = new Thickness(offsetX, offsetY, 0, 0);
            await Task.Delay(10);
            menuFlyout.ShowAt(contextMenuPlace, new Point(0,0));
        }

        private void NoteFieldPasteEventHandler()
        {
            NoteFieldPasteEvent?.Invoke();
        }       

        private void NoteFieldTextChangedEventHandler(string fieldName, string html)
        {
            IsContentCheckOnce = true;
            if (IsModified == false)
            {                
                var text = html.Replace("&nbsp;", " ");                
                if (String.IsNullOrWhiteSpace(text))
                    return;

                IsModified = true;
            }            
            currentNote.SetItem(fieldName, html);
        }

        private void AddWebViewControlIntoGrid()
        {            
            webViewControl = new WebView();
            ScrollViewer.SetVerticalScrollBarVisibility(webViewControl, ScrollBarVisibility.Hidden);            
            webViewGrid.Children.Add(webViewControl);
            HookWebViewEvents();
        }

        private void HookWebViewEvents()
        {
            webViewControl.NavigationStarting += WebViewControlNavigationStartingHandler;
            webViewControl.NavigationCompleted += WebViewControlNavigationCompletedHandler;
        }

        private void WebViewControlNavigationStartingHandler(WebView sender, WebViewNavigationStartingEventArgs args)
        {
            //Inject bojects into javascript with the corresponding name 
            webViewControl.AddWebAllowedObject("buttonNotify", buttonEventNotify);
            webViewControl.AddWebAllowedObject("noteFieldNotify", noteFieldEventNotify);
        }

        private async void WebViewControlNavigationCompletedHandler(WebView sender, WebViewNavigationCompletedEventArgs args)
        {
            isWebviewReady = true;
            if (UIHelper.IsHasPhysicalKeyboard())
                await IsTouchInput(false);
            else
                await IsTouchInput(true);

            await ChangeReadMode();

            if (deckMediaFolderName != null)
                await ChangeDeckMediaFolder(deckMediaFolderName);

            if (currentNote != null)            
                await PopulateNoteField();

            await ChangeTinymceToolBarWidth(WindowSizeStates.CurrentState.Name);
            await InitRichTextEditor();
        }

        private void UserControlLoadedHandler(object sender, RoutedEventArgs e)
        {
            NavigateWebviewToLocalPage();
        }

        private void NavigateWebviewToLocalPage()
        {
            TinymceStreamUriWinRTResolver resolver = new TinymceStreamUriWinRTResolver();
            var localUri = webViewControl.BuildLocalStreamUri("NoteFieldEditor", HTML_PATH);
            webViewControl.NavigateToLocalStreamUri(localUri, resolver);
        }

        private async Task PopulateNoteField()
        {            
            List<string> fields = new List<string>();
            foreach (var f in currentNote.Model["flds"].GetArray())
            {
                string name = f.GetObject().GetNamedString("name");
                string content = currentNote.GetItem(name);
                fields.Add(name);
                fields.Add(content);                
            }
            await PopulateAllNoteField(fields);
            isNoteFieldPopulate = true;
        }

        private async Task PopulateAllNoteField(List<string> fields)
        {
            try
            {                
                await webViewControl.InvokeScriptAsync("PopulateAllNoteField", fields);
            }
            catch (Exception ex)
            {
                UIHelper.ThrowJavascriptError(ex.HResult);
            }
        }

        private async Task ClearBody()
        {
            try
            {                
                await webViewControl.InvokeScriptAsync("ClearBody", null);
            }
            catch (Exception ex)
            {
                UIHelper.ThrowJavascriptError(ex.HResult);
            }
        }

        private async Task ChangeAllNoteFieldContent(Note note)
        {
            try
            {                
                await webViewControl.InvokeScriptAsync("ChangeAllNoteFieldContent", note.Fields);
            }
            catch (Exception ex)
            {
                UIHelper.ThrowJavascriptError(ex.HResult);
            }
        }

        /// <summary>
        /// Until Microsoft fix their caching problem,
        /// This function is very IMPORTANT to clear webview cache
        /// It will have to be used each time user stop viewing deck
        /// </summary>
        public void ClearWebViewControl()
        {
            isWebviewReady = false;
            webViewGrid.Children.Clear();
            webViewControl = null;
            GC.Collect();
        }

        public async Task ChangeDeckMediaFolder(string path)
        {
            try
            {
                await webViewControl.InvokeScriptAsync("ChangeDeckMediaFolder", new string[] { path });
            }
            catch (Exception ex)
            {
                UIHelper.ThrowJavascriptError(ex.HResult);
            }
        }

        public async Task InitRichTextEditor()
        {
            try
            {
                await webViewControl.InvokeScriptAsync("InitRichTextEditor", null);
            }
            catch (Exception ex)
            {
                UIHelper.ThrowJavascriptError(ex.HResult);
            }
        }

        private async Task ChangeReadMode()
        {
            try
            {
                string mode;
                if (isNightMode)
                    mode = "night";
                else
                    mode = "day";
                await webViewControl.InvokeScriptAsync("ChangeReadMode", new string[] { mode });
            }
            catch (Exception ex)
            {
                UIHelper.ThrowJavascriptError(ex.HResult);
            }
        }

        public async Task InsertIntoRichTextEditor(string text)
        {
            try
            {
                await webViewControl.InvokeScriptAsync("InsertIntoTinymce", new string[] { text });
            }
            catch (Exception ex)
            {
                UIHelper.ThrowJavascriptError(ex.HResult);
            }
        }

        private void AdaptiveTriggerCurrentStateChanged(object sender, VisualStateChangedEventArgs e)
        {
            //WANRING: This will cause memory leak
            //await LoadNewToolBarWidth(WindowSizeStates.CurrentState.Name);
        }

        private async Task ChangeTinymceToolBarWidth(string size)
        {
            try
            {
                await webViewControl.InvokeScriptAsync("ChangeTinymceToolBarWidth", new string[] { size });
            }
            catch (Exception ex)
            {
                UIHelper.ThrowJavascriptError(ex.HResult);
            }
        }

        public async Task InsertCloze(int count)
        {
            try
            {
                await webViewControl.InvokeScriptAsync("InsertCloze", new string[] { count.ToString() });
            }
            catch (Exception ex)
            {
                UIHelper.ThrowJavascriptError(ex.HResult);
            }
        }

        public async Task HideEditor()
        {
            try
            {
                await webViewControl.InvokeScriptAsync("HideEditor", null);
            }
            catch (Exception ex)
            {
                UIHelper.ThrowJavascriptError(ex.HResult);
            }
        }

        public async Task ShowEditor()
        {
            try
            {
                await webViewControl.InvokeScriptAsync("ShowEditor", null);
            }
            catch (Exception ex)
            {
                UIHelper.ThrowJavascriptError(ex.HResult);
            }
        }

        private async Task IsTouchInput(bool value)
        {
            try
            {
                string str;
                if (value)
                    str = "true";
                else
                    str = "false";
                await webViewControl.InvokeScriptAsync("IsTouchInput", new string[] { str });
            }
            catch (Exception ex)
            {
                UIHelper.ThrowJavascriptError(ex.HResult);
            }
        }

        public async Task ForceNotifyContentChanged()
        {
            try
            {                
                await webViewControl.InvokeScriptAsync("ForceNotifyContentChanged", null);
            }
            catch (Exception ex)
            {
                UIHelper.ThrowJavascriptError(ex.HResult);
            }
        }

        private async Task LoadNewToolBarWidth(string size)
        {
            try
            {
                await webViewControl.InvokeScriptAsync("LoadNewToolBarWidth", new string[] { size });
            }
            catch (Exception ex)
            {
                UIHelper.ThrowJavascriptError(ex.HResult);
            }
        }
        
        private void ButtonEventNotifyClickEventHandler(object sender)
        {
            //Schedule to run this in another thread so javascript
            //can continue to excute its events
            Task.Run(() =>
            {
                string str = sender as string;
                if (str == "enter")
                {
                    var task = InsertLineBreak();
                }
                else
                    WebviewButtonClickEvent?.Invoke(sender);
            });
        }

        /// <summary>
        /// This function should only be used to deal with touch input only.
        /// Tinymce and enter key of touch keyboard on win 10 mobile does not work well with each other
        /// so we have to handle it differently
        /// </summary>
        private bool isEnterTimeOut = true;
        private async Task InsertLineBreak()
        {
            try
            {
                if (isEnterTimeOut)
                {
                    isEnterTimeOut = false;
                    await webViewControl.Dispatcher.RunAsync(CoreDispatcherPriority.Normal, () =>
                    {
                          var task = webViewControl.InvokeScriptAsync("InsertLineBreak", null);
                    });
                    await Task.Delay(250);
                    isEnterTimeOut = true;
                }
            }
            catch (Exception ex)
            {
                UIHelper.ThrowJavascriptError(ex.HResult);
            }
        }

        public async void ToggleReadMode()
        {
            isNightMode = !isNightMode;
            if (isWebviewReady)
                await ChangeReadMode();
        }

        private void FieldContextMenuPaste(object sender, RoutedEventArgs e)
        {
            NoteFieldPasteEvent?.Invoke();
        }

        public void ReloadWebView()
        {
            ClearWebViewControl();
            AddWebViewControlIntoGrid();
            NavigateWebviewToLocalPage();
        }
    }   
}
